package com.bdyc.verifycode;


import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bdyc.utils.VerifyCode;

public class VerifyCodeServlet extends HttpServlet {
	 public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        
        //设置浏览器不缓存本页
        response.setHeader("Cache-Control", "no-cache");
        
        //生成验证码，写入用户session
        String verifyCode=VerifyCode.generateTextCode(VerifyCode.TYPE_ALL_MIXED,4,null);
        request.getSession().setAttribute("verifyCode",verifyCode);
        
        //输出验证码给客户端
        response.setContentType("image/jpeg");
        BufferedImage bim=VerifyCode.generateImageCode(verifyCode, 100, 35, 3,true,Color.WHITE,Color.BLACK,null);
        ImageIO.write(bim, "JPEG",response.getOutputStream());    
    }
}
